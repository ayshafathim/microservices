package com.UST.Flightservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
